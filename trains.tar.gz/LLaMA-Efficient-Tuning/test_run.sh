mkdir ../final_v3_test
cd ../final_v3_test
touch 123.txt

# upload
cd ..
python upload_model.py